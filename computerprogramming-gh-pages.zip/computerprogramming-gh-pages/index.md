# Welcome to Carter Newberg's Programmiing Portfolio

## Programming Semester 1 Projects:

## Programming Semester 2 Projects:

### Calculator Project
